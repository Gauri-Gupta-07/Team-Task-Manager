
package com.example.taskmanager.service;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.taskmanager.repository.UserRepository;
import com.example.taskmanager.model.User;

@Service
public class UserService {
 @Autowired
 private UserRepository repo;

 public User register(User user){
   return repo.save(user);
 }
}
