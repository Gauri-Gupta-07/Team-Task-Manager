
package com.example.taskmanager.model;
import jakarta.persistence.*;

@Entity
public class User {
 @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;
 private String username;
 private String password;
 private String role;

 public Long getId(){return id;}
 public void setId(Long id){this.id=id;}
 public String getUsername(){return username;}
 public void setUsername(String u){this.username=u;}
 public String getPassword(){return password;}
 public void setPassword(String p){this.password=p;}
 public String getRole(){return role;}
 public void setRole(String r){this.role=r;}
}
