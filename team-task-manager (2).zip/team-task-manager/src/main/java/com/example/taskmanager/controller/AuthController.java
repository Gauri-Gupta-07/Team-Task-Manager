
package com.example.taskmanager.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.taskmanager.service.UserService;
import com.example.taskmanager.model.User;

@RestController
@RequestMapping("/auth")
public class AuthController {

 @Autowired
 private UserService service;

 @PostMapping("/signup")
 public User signup(@RequestBody User user){
   return service.register(user);
 }
}
