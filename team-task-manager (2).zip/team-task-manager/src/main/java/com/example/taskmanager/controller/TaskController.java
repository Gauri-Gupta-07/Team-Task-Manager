
package com.example.taskmanager.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.taskmanager.service.TaskService;
import com.example.taskmanager.model.Task;
import java.util.List;

@RestController
@RequestMapping("/tasks")
public class TaskController {

 @Autowired
 private TaskService service;

 @PostMapping
 public Task create(@RequestBody Task t){
   return service.create(t);
 }

 @GetMapping
 public List<Task> all(){
   return service.getAll();
 }
}
