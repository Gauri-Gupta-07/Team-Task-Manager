
package com.example.taskmanager.service;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.taskmanager.repository.TaskRepository;
import com.example.taskmanager.model.Task;
import java.util.List;

@Service
public class TaskService {
 @Autowired
 private TaskRepository repo;

 public Task create(Task t){ return repo.save(t); }
 public List<Task> getAll(){ return repo.findAll(); }
}
